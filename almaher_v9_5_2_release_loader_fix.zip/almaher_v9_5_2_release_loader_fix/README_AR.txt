V9.5.2 — RELEASE LOADER FIX

المشكلة:
الرابط / كان يعرض APP_HTML المدمج دائمًا، لذلك تفعيل HTML من system_releases لم يكن يغيّر النسخة العادية.

الإصلاح:
- / يعرض آخر Stable مفعّل من system_releases.
- /?release=test يعرض آخر Test مفعّل.
- /?release=embedded يعرض النسخة المدمجة للطوارئ.
- fallback تلقائي للنسخة المدمجة إذا تعذر تحميل Supabase.

للتثبيت الآن:
استبدل index.js فقط. لا حاجة لتغيير wrangler.toml أو المفاتيح.
بعد Deploy افتح /?release=test لاختبار V9.5.1 الحالية.
بعد نجاح الاختبار فعّل V9.5.1 على Stable، ثم الرابط العادي / سيعرضها تلقائيًا.
