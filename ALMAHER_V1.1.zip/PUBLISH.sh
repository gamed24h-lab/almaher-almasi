#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"

echo "[1/4] Syncing Git branch..."
git fetch origin
CURRENT_BRANCH="$(git branch --show-current)"
if [ "$CURRENT_BRANCH" != "main" ]; then
  git branch -M main
fi
# The remote main already exists after the GitHub branch rename.
git branch --set-upstream-to=origin/main main >/dev/null 2>&1 || true

echo "[2/4] Cleaning upload helpers..."
rm -f ALMAHER_NEXT_MAIN_UPLOAD.zip PUBLISH.sh

echo "[3/4] Staging ALMAHER NEXT only..."
git add -- .gitignore .node-version BUILD_STATUS.txt DEPLOY_CHECKLIST_AR.md README_AR.md index.html package.json vite.config.js wrangler.toml src worker supabase

if git diff --cached --quiet; then
  echo "No project changes to commit."
else
  git commit -m "ALMAHER NEXT V1.1.0 operational completion"
fi

echo "[4/4] Pushing to origin/main..."
git push -u origin main

echo "DONE: ALMAHER NEXT V1.1.0 is now on GitHub main."
